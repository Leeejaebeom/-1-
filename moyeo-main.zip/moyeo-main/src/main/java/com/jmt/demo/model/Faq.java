package com.jmt.demo.model;

import lombok.Data;

@Data
public class Faq {

	private Long faq_id;
	private String question;
	private String answer;
	
}
