package com.jmt.demo.dao;

import com.jmt.demo.model.TravelPlan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class TravelPlanDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<TravelPlan> findAll() {
        String sql = "SELECT * FROM travel_plans ORDER BY plan_id DESC";
        return jdbcTemplate.query(sql, new TravelPlanRowMapper());
    }

    public TravelPlan findById(Long planId) {
        String sql = "SELECT * FROM travel_plans WHERE plan_id = ?";
        return jdbcTemplate.queryForObject(sql, new TravelPlanRowMapper(), planId);
    }

    public void save(TravelPlan travelPlan) {
        String sql = "INSERT INTO travel_plans (user_id, title, description, start_date, end_date, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())";
        jdbcTemplate.update(sql, travelPlan.getUser_id(), travelPlan.getTitle(), travelPlan.getDescription(), travelPlan.getStart_date(), travelPlan.getEnd_date());
    }

    public void update(TravelPlan travelPlan) {
        String sql = "UPDATE travel_plans SET title = ?, description = ?, start_date = ?, end_date = ?, updated_at = NOW() WHERE plan_id = ?";
        jdbcTemplate.update(sql, travelPlan.getTitle(), travelPlan.getDescription(), travelPlan.getStart_date(), travelPlan.getEnd_date(), travelPlan.getPlan_id());
    }

    public void delete(int planId) {
    	
    	String sql ="DELETE FROM companions WHERE plan_id = ?";
        jdbcTemplate.update(sql, planId);
    	
        String sql1 ="DELETE FROM travel_plans WHERE plan_id = ?";
        jdbcTemplate.update(sql1, planId);
        
       
    }
    
    public List<TravelPlan> PlanSearch(String keyword){
		String sql = "SELECT plan_id, travel_plans.user_id AS user_id, title, description, start_date, end_date, travel_plans.created_at AS created_at, travel_plans.updated_at AS updated_at "
				+ "FROM travel_plans, users "
				+ "WHERE title LIKE ? OR (username LIKE ? AND travel_plans.user_id = users.user_id) ORDER BY travel_plans.plan_id DESC";
		return jdbcTemplate.query(sql, new TravelPlanRowMapper(), "%"+keyword+"%", "%"+keyword+"%");
	}

    private static final class TravelPlanRowMapper implements RowMapper<TravelPlan> {
        @Override
        public TravelPlan mapRow(ResultSet rs, int rowNum) throws SQLException {
            TravelPlan travelPlan = new TravelPlan();
            travelPlan.setPlan_id(rs.getLong("plan_id"));
            travelPlan.setUser_id(rs.getInt("user_id"));
            travelPlan.setTitle(rs.getString("title"));
            travelPlan.setDescription(rs.getString("description"));
            travelPlan.setStart_date(rs.getDate("start_date"));
            travelPlan.setEnd_date(rs.getDate("end_date"));
            travelPlan.setCreated_at(rs.getTimestamp("created_at"));
            travelPlan.setUpdated_at(rs.getTimestamp("updated_at"));
            return travelPlan;
        }
    }
}