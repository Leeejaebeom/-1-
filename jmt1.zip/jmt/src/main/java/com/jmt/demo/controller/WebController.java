package com.jmt.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

	@GetMapping("/registerPage")
	public String registerPage() {
		return "registerPage";
	}

	@GetMapping("/loginPage")
	public String loginPage() {
		return "index";
	}

	@GetMapping("main")
	public String main() {
		return "main";
	}

	@GetMapping("test")
	public String test() {
		return "test";
	}
	
}
