package com.jmt.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jmt.demo.dao.QaDAO;
import com.jmt.demo.dao.TravelPlanDao;
import com.jmt.demo.dao.UserDAO;
import com.jmt.demo.model.Page;
import com.jmt.demo.model.Qa;
import com.jmt.demo.model.TravelPlan;
import com.jmt.demo.model.User;


@Controller
@RequestMapping("/")
public class QaController {
	
	@Autowired
	private QaDAO QaDao;

	@Autowired
	private UserDAO userDao;
	
	@Autowired
    private TravelPlanDao travelPlanDao;

	
	@GetMapping
	public String Qa(Model model, Integer pageNum) {
		
		List<User> userList = userDao.allUsers();
		model.addAttribute("userList", userList);
		List<TravelPlan> travelPlanList = travelPlanDao.findAll();
        model.addAttribute("travelPlanList", travelPlanList);
        List<Qa> qaList = QaDao.findQa();
		model.addAttribute("qaList", qaList);
		
		paging(model, pageNum, travelPlanList);
		
		return "index";
	}
	
	public <T> void paging(Model model, Integer pageNum, List<T> list) {
		int total = list.size();
		int currentPage;
		if (pageNum == null) {
			currentPage = 1;
		} else {
			currentPage = pageNum;
		}
		Page page = new Page(currentPage, total);
		model.addAttribute("page", page);
	}
	
	
	// 같이갈래?
	
	// 같이갈래? - 게시물 등록
	@PostMapping("/planRegister")
    public String addTravelPlan(@ModelAttribute("travelPlan") TravelPlan travelPlan) {
        travelPlanDao.save(travelPlan);
        return "redirect:/";
    }
	
	// 같이갈래? - 검색
	@GetMapping("/joinSearch")
	public String JoinSearch(Model model, String keyword, Integer pageNum) {
		if (keyword == "") {
			return "redirect:/";
		} else {
			List<TravelPlan> travelPlanList = travelPlanDao.PlanSearch(keyword);
			model.addAttribute("travelPlanList", travelPlanList);
			List<User> userList = userDao.allUsers();
			model.addAttribute("userList", userList);
			
			paging(model, pageNum, travelPlanList);
			model.addAttribute("keyword",keyword);
			return "index";
		}
	}
	
	// 같이갈래? - 수정
	@GetMapping("/planEdit")
	public String JoinEdit(TravelPlan travelPlan) {
		travelPlanDao.update(travelPlan);
		return "redirect:/";
	}
	
	// 같이갈래? - 삭제
	@GetMapping("/planDelete")
	public String JoinDelete(int plan_id) {
		travelPlanDao.delete(plan_id);
		return "redirect:/";
	}
	
	
	// QA
	
	// QA 등록
	@GetMapping("/QaRegister")
	public String QaRegister(Qa qa) {
		QaDao.QaRegister(qa);
		return "redirect:/";
	}

	
	// QA 검색
	@GetMapping("/QaSearch")
	public String QaSearch(Model model, String keyword, Integer pageNum) {
		if (keyword == "") {
			return "redirect:/";
		} else {
			List<Qa> qaList = QaDao.QaSearch(keyword);
			model.addAttribute("qaList", qaList);
			List<User> userList = userDao.allUsers();
			model.addAttribute("userList", userList);
			
			paging(model, pageNum, qaList);
			model.addAttribute("keyword",keyword);
			return "index";
		}
	}
	
	

}
