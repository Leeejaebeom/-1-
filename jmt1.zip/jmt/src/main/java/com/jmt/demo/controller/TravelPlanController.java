package com.jmt.demo.controller;

import com.jmt.demo.dao.TravelPlanDao;
import com.jmt.demo.model.TravelPlan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/travel-plans")
public class TravelPlanController {

    @Autowired
    private TravelPlanDao travelPlanDao;

    @GetMapping
    public String getAllTravelPlans(Model model) {
        List<TravelPlan> travelPlans = travelPlanDao.findAll();
        model.addAttribute("travelPlans", travelPlans);
        return "travelPlanList";
    }

    @GetMapping("/new")
    public String showAddTravelPlanForm(Model model) {
        model.addAttribute("travelPlan", new TravelPlan());
        return "addTravelPlan";
    }

    @PostMapping
    public String addTravelPlan(@ModelAttribute("travelPlan") TravelPlan travelPlan) {
        travelPlanDao.save(travelPlan);
        return "redirect:/travel-plans";
    }

    @GetMapping("/{planId}")
    public String getTravelPlan(@PathVariable Long planId, Model model) {
        TravelPlan travelPlan = travelPlanDao.findById(planId);
        model.addAttribute("travelPlan", travelPlan);
        return "viewTravelPlan";
    }

    @GetMapping("/{planId}/edit")
    public String showEditTravelPlanForm(@PathVariable Long planId, Model model) {
        TravelPlan travelPlan = travelPlanDao.findById(planId);
        model.addAttribute("travelPlan", travelPlan);
        return "editTravelPlan";
    }

    @PostMapping("/{planId}")
    public String updateTravelPlan(@PathVariable Long planId, @ModelAttribute("travelPlan") TravelPlan travelPlan) {
        travelPlan.setPlan_id(planId);
        travelPlanDao.update(travelPlan);
        return "redirect:/travel-plans";
    }

    @PostMapping("/{planId}/delete")
    public String deleteTravelPlan(@PathVariable int planId) {
        travelPlanDao.delete(planId);
        return "redirect:/travel-plans";
    }
}